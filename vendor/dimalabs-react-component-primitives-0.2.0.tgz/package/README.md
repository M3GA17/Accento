# DimaLabs React Component Primitives

Versione locale **0.2.0**: aggiunto [LanguageSelector](dist/language-selector.md), con selezione singola, ricerca opzionale, form/reset e bandiere opzionali. Include 542 asset SVG importabili da `@dimalabs/react-component-primitives/flags/*`; sono separati dal JavaScript.

Button, TextBox, Combobox e SearchBar per React DOM. Comportamento condiviso e parti accessibili, senza CSS Material o tema. Base: React Aria Components 1.22.1. React e React DOM sono peer dependency; React Native richiede un'altra implementazione.

## Uso

```tsx
import { Button, Combobox, TextBox, SearchBar } from '@dimalabs/react-component-primitives';
<Button onPress={() => save()} loading={saving}>Salva</Button>
<TextBox label="Nome" name="name" required defaultValue="" />
<Combobox<number> label="Categorie" options={[{value:12,label:'Design'}]}
  multiple value={categoryIds} onValueChange={setCategoryIds} />
<SearchBar label="Cerca" onSearch={query => search(query)} />
```

Le proprietà visive appartengono alla presentazione. I campi accettano render(parts) per comporre i nodi funzionali senza duplicare stato o focus. Gli ID delle opzioni devono essere univoci.

Valori controllati con value/onValueChange o iniziali con defaultValue. Nei form non controllati, reset ripristina il valore iniziale.

ESM e dichiarazioni TypeScript. Versione preparata e verificata localmente, non pubblicata su npm.
