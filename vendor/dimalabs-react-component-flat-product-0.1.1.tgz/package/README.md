# React DOM · Flat Product

Presentazione delle primitive DimaLabs: Button, TextBox, Combobox e LanguageSelector.
Importare `styles.css` e `themes.css`, poi applicare `data-dimalabs-theme="light"` o `"dark"` a `document.documentElement` per includere i popup nei portal.
I temi derivano da `design/figcraft/product-flat.variables.json`; build dalla radice con `npm run flat:build`.
Il consumatore gestisce traduzioni, persistenza e dominio. I comportamenti accessibili restano nelle primitive React Aria.
