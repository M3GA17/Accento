"""Build Accento's editable native FigCraft library with the installed MCP CLI.

No server configuration, publishing, or unrelated project mutation is required.
Run: python scripts/create-figcraft-system.py
"""
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'design' / 'figcraft'
CLI = Path(os.environ.get('FIGCRAFT_CLI', r'C:\Program Files\FigCraft\figcraft-cli.exe'))


class MCP:
    def __init__(self):
        self.proc = subprocess.Popen([str(CLI), 'mcp'], stdin=subprocess.PIPE,
                                     stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                     text=True, encoding='utf-8')
        self.seq = 0
        self.request('initialize', {'protocolVersion': '2025-06-18', 'capabilities': {},
                     'clientInfo': {'name': 'Accento design system builder', 'version': '0.2.0'}})
        self.proc.stdin.write(json.dumps({'jsonrpc': '2.0', 'method': 'notifications/initialized'})+'\n')
        self.proc.stdin.flush()

    def request(self, method, params):
        self.seq += 1
        self.proc.stdin.write(json.dumps({'jsonrpc': '2.0', 'id': self.seq,
                                         'method': method, 'params': params}, ensure_ascii=False)+'\n')
        self.proc.stdin.flush()
        line = self.proc.stdout.readline()
        if not line:
            raise RuntimeError('FigCraft MCP exited before responding')
        reply = json.loads(line)
        if 'error' in reply:
            raise RuntimeError(reply['error'])
        return reply['result']

    def call(self, tool, **args):
        result = self.request('tools/call', {'name': tool, 'arguments': args})
        contents = '\n'.join(c['text'] for c in result.get('content', []) if c['type'] == 'text')
        if result.get('isError'):
            raise RuntimeError(f'{tool} {args}: {contents}')
        try:
            return json.loads(contents)
        except json.JSONDecodeError:
            return contents

    def command(self, command, **params):
        return self.call('run_command', command=command, params=params)

    def close(self):
        self.proc.stdin.close()
        self.proc.wait(timeout=15)


TOKENS = {
    'Light': {'canvas':'#ECF0F6', 'ink':'#1F2633', 'secondary':'#637082',
              'tertiary':'#8C96A6', 'accent':'#295ED1', 'inset':'#F4F6FB',
              'glass-start':'#FFFFFF', 'glass-middle':'#F9FAFE', 'glass-end':'#DFE7F2',
              'rim':'#FFFFFFF5', 'inner-rim':'#859CBD38', 'selection':'#619CFF26',
              'selection-rim':'#477DE3A6', 'hover':'#FFFFFF4D', 'success':'#28A667',
              'error':'#C52E46', 'separator':'#667FA61F'},
    'Dark': {'canvas':'#13161D', 'ink':'#F5F7FC', 'secondary':'#A3B0C4',
             'tertiary':'#738299', 'accent':'#6EA8FF', 'inset':'#171C29',
             'glass-start':'#404757', 'glass-middle':'#2B303E', 'glass-end':'#212633',
             'rim':'#FFFFFF38', 'inner-rim':'#00000047', 'selection':'#4078E638',
             'selection-rim':'#7AB0FFD9', 'hover':'#FFFFFF13', 'success':'#63D898',
             'error':'#FF8794', 'separator':'#FFFFFF12'}
}
METRICS = {'space/1':4, 'space/2':8, 'space/3':12, 'space/4':16, 'space/6':24,
           'space/8':32, 'space/10':40, 'radius/option':22, 'radius/candidate':16,
           'radius/panel':24, 'radius/field':12, 'radius/action':14,
           'size/option':144, 'size/option-target':160, 'size/candidate':64,
           'size/field':43, 'size/save':48, 'size/settings-width':900,
           'size/settings-height':936, 'size/picker-height':142,
           'stroke/hairline':0.6, 'stroke/edge':1, 'stroke/selected':1.4,
           'stroke/focus':2, 'time/open-default-ms':300, 'time/press-offset':1}


def color(value):
    value = value.lstrip('#')
    return dict(zip(('r', 'g', 'b', 'a'), [int(value[i:i+2],16)/255 for i in range(0,len(value),2)] +
                    ([1] if len(value)==6 else [])))


class System:
    def __init__(self):
        OUT.mkdir(parents=True, exist_ok=True)
        (OUT/'previews').mkdir(exist_ok=True)
        self.m = MCP()
        self.m.command('file.new', name='Accento / Liquid Glass Design System')
        self.collection = self.m.command('variable.createCollection', name='Accento / Appearance', modes=['Light','Dark'])['id']
        self.variables = {}
        for role in TOKENS['Light']:
            self.variables[role] = self.m.command('variable.create', collection=self.collection,
                name='color/'+role, type='color', values={m:v[role] for m,v in TOKENS.items()})['id']
        for role, value in METRICS.items():
            self.variables[role] = self.m.command('variable.create', collection=self.collection,
                name=role, type='number', values={'Light':value,'Dark':value})['id']
        self.pages, self.boards, self.components, self.sets, self.styles = [], [], {}, {}, {}

    def bind(self, node, field, role):
        self.m.command('variable.bind', ids=[node], field=field, variable=self.variables[role])
        # Hex alpha initializes paint opacity too. Binding an RGBA variable would
        # multiply the two alphas; keep alpha entirely in the variable value.
        if field in ['fill','stroke']:
            self.m.command('fill.set' if field=='fill' else 'stroke.set',ids=[node],index=0,opacity=1)

    def node(self, typ, parent, name, x,y,w,h, role=None, **props):
        if role:
            props['fill'] = TOKENS['Light'][role]
        extra = {'path':props.pop('path')} if 'path' in props else {}
        node = self.m.call('create_node',type=typ,parent=parent,name=name,x=x,y=y,width=w,height=h,props=props,**extra)['id']
        if role:
            self.bind(node,'fill',role)
        return node

    def set(self, node, **props):
        return self.m.call('set_properties', ids=[node], props=props)

    def rect(self,p,n,x,y,w,h,role=None,r=0,**props):
        return self.node('rectangle',p,n,x,y,w,h,role,cornerRadius=r,**props)

    def text(self,p,t,x,y,w,size=14,role='ink',bold=False,h=None,align='left'):
        height = h or size*1.5
        node = self.node('text',p,t,x,y,w,height,role,characters=t,fontFamily='Segoe UI Variable',
            fontStyle='Semibold' if bold else 'Regular',fontSize=size,lineHeight=size*1.4,
            textAutoResize='none',textAlign=align,textAlignVertical='middle')
        key=f'Accento/{size}/'+('Semibold' if bold else 'Regular')
        if key not in self.styles:
            self.styles[key] = self.m.command('style.create', type='text',name=key,
                value={'fontFamily':'Segoe UI Variable','fontStyle':'Semibold' if bold else 'Regular',
                       'fontSize':size,'lineHeight':size*1.4})['id']
        self.m.command('style.apply', ids=[node],style=self.styles[key])
        # Applying a shared text style recalculates the box in FigCraft 0.6.0.
        # Restore the explicit control box to preserve optical centering.
        self.set(node,width=w,height=height,textAutoResize='none',textAlignVertical='middle')
        return node

    def page(self,name):
        if not self.pages:
            page=self.m.call('inspect_document')['pages'][0]['id']
            self.m.command('page.rename',id=page,name=name)
        else:
            page=self.m.command('page.add',name=name)['id']
        self.m.command('page.select',id=page)
        self.m.command('page.setBackground',color='#333B4C')
        self.pages.append(page)
        return page

    def frame(self,p,n,mode,x,y,w,h):
        node=self.node('frame',p,n,x,y,w,h,'canvas',clip=True)
        self.m.command('variable.setMode',ids=[node],collection=self.collection,mode=mode)
        return node

    def board(self,p,n,mode,x=0,w=1320,h=1000):
        node=self.frame(p,n+' / '+mode,mode,x,0,w,h)
        self.text(node,'ACCENTO  /  DESIGN SYSTEM',48,36,w-96,11,'secondary',True)
        self.text(node,n,48,70,w-96,34,bold=True)
        self.text(node,'Liquid Glass · '+('Chiaro' if mode=='Light' else 'Scuro')+' · Windows / Rust',50,122,w-100,14,'secondary')
        self.text(node,'ACCENTO 0.2  /  15 OTTOBRE 2026',48,h-38,w-96,10,'tertiary')
        self.boards.append({'id':node,'name':n,'mode':mode,'width':w,'height':h})
        return node

    def glass(self,p,x,y,w,h,r=22,selected=False,state='default',material='glass'):
        roles=['glass-start','glass-middle','glass-end']
        if material=='opaque':
            surface=self.rect(p,'Opaque surface',x,y,w,h,'inset',r=r)
        else:
            paint={'type':'gradient','kind':'linear','from':[0,0],'to':[1,1],
                   'stops':[{'position':pos,'color':color(TOKENS['Light'][role])}
                            for pos,role in zip([0,.45,1],roles)]}
            surface=self.rect(p,'Optical glass / diagonal light',x,y,w,h,r=r,fills=[paint],
                effects=[{'type':'dropShadow','color':'#050A1718','radius':5,'offsetX':0,'offsetY':3}])
            for i,role in enumerate(roles):
                self.bind(surface,f'fills/0/stops/{i}/color',role)
        if selected:
            self.rect(p,'Selection tint',x,y,w,h,'selection',r=r)
        if state=='hover':
            self.rect(p,'Hover illumination',x,y,w,h,'hover',r=r)
        if state=='pressed':
            self.rect(p,'Pressure shade',x,y+1,w,h,r=r,fill='#1F386112')
        rim=self.rect(p,'Outer reflective rim',x+.6,y+.6,w-1.2,h-1.2,r=r-.6,
                      fills=[],stroke=TOKENS['Light']['rim'],strokeWeight=1)
        self.bind(rim,'stroke','rim')
        rim=self.rect(p,'Inner refractive edge',x+1.7,y+1.7,w-3.4,h-3.4,r=r-1.7,
                      fills=[],stroke=TOKENS['Light']['inner-rim'],strokeWeight=.6)
        self.bind(rim,'stroke','inner-rim')
        if selected:
            rim=self.rect(p,'Selected outline',x+.7,y+.7,w-1.4,h-1.4,r=r-.7,
                          fills=[],stroke=TOKENS['Light']['selection-rim'],strokeWeight=1.4)
            self.bind(rim,'stroke','selection-rim')
        if state=='focus':
            rim=self.rect(p,'Keyboard focus / 2 px',x-2.5,y-2.5,w+5,h+5,r=r+2.5,
                          fills=[],stroke=TOKENS['Light']['accent'],strokeWeight=2)
            self.bind(rim,'stroke','accent')
        return surface

    def check(self,p,x,y,on):
        self.node('ellipse',p,'Selection indicator',x-9,y-9,18,18,'accent' if on else 'separator')
        if on:
            self.node('vector',p,'Check / original vector',x-4,y-4,9,8,path='M 0 4 L 3 7 L 9 0',
                      fills=[],stroke='#FFFFFF',strokeWeight=1.6,strokeCap='round',strokeJoin='round')

    def component(self,p,family,key,x,y,w,h):
        node=self.node('component',p,key,x,y,w,h,fills=[],clip=False,
                       description=f'Accento {family}; editable optical reference. Runtime mapping in handoff.json.')
        self.components[(family,key)]=node
        return node

    def property(self,c,name,node,value):
        self.m.command('component.addProperty',id=c,name=name,type='text',default=value,layer=node)

    def candidate(self,p,key,x,y,selected=False,material='glass',glyph='è'):
        c=self.component(p,'Candidate',key,x,y,64,64)
        self.glass(c,0,0,64,64,16,selected,material=material)
        self.bind(c,'width','size/candidate'); self.bind(c,'height','size/candidate')
        label=self.text(c,glyph,0,0,64,32,'accent' if selected else 'ink',h=60,align='center')
        self.property(c,'Glyph',label,glyph)
        if selected:
            self.node('ellipse',c,'Selected dot',30.2,54.2,3.6,3.6,'accent')
        return c

    def option(self,p,key,x,y,kind='language',selected=False,state='default',glyph='à',label='Italiano',hint='IT'):
        c=self.component(p,'OptionTile',key,x,y,144,144)
        self.glass(c,0,0,144,144,22,selected,state)
        self.bind(c,'width','size/option'); self.bind(c,'height','size/option')
        self.check(c,122,22,selected)
        if kind=='language':
            t=self.text(c,glyph,0,24,144,40,h=64,align='center')
            self.property(c,'Glyph',t,glyph)
        elif kind=='toggle':
            self.rect(c,'Switch track',45,44,54,30,'accent' if selected else 'secondary',r=15)
            self.node('ellipse',c,'Switch thumb',73 if selected else 49,48,22,22,fill='#FFFFFF')
        else:
            dark=kind=='theme-dark'
            self.rect(c,'Mini window',42,36,60,42,r=8,fill='#20293B' if dark else '#FDFEFF',stroke='#8999B947',strokeWeight=.7)
            self.rect(c,'Sidebar',48,42,12,30,r=3,fill='#526078' if dark else '#DCE7F6')
            for j in range(3):
                self.rect(c,'Content line',66,43+j*9,28,4,r=2,fill='#63718A' if dark else '#A2B4D0')
            if kind=='theme-system':
                self.rect(c,'System / dark half',72,36,30,42,r=[0,8,8,0],fill='#20293B')
                for j in range(3): self.rect(c,'Dark content line',76,43+j*9,20,4,r=2,fill='#63718A')
        t=self.text(c,label,4,96,136,14,bold=True,h=24,align='center')
        self.property(c,'Label',t,label)
        t=self.text(c,hint,4,122,136,10,'secondary',h=16,align='center')
        self.property(c,'Hint',t,hint)
        return c

    def instance(self,c,p,x,y,**properties):
        inst=self.m.command('instance.create',component=c,parent=p,x=x,y=y)['id']
        if properties:
            self.m.command('instance.setProperties',ids=[inst],properties=properties)
        return inst

    def combine(self,family,ids):
        self.m.command('component.combineVariants',ids=ids)
        sets=self.m.command('component.list')
        s=next(c for c in reversed(sets) if c['type']=='COMPONENT_SET' and c['name'] not in self.sets)
        self.set(s['id'],name=family,clip=False,fills=[],strokes=[])
        self.sets[family]=s['id']

    def options_page(self):
        p=self.page('03 / Opzioni quadrate')
        boards=[self.board(p,'Opzioni quadrate',mode,i*1400,h=1560) for i,mode in enumerate(TOKENS)]
        specs=[('Language','Off','default'),('Language','On','default'),('Language','Off','hover'),
               ('Language','On','pressed'),('Language','Off','focus'),('Language','On','focus'),
               ('ThemeSystem','Off','default'),('ThemeSystem','On','default'),
               ('ThemeLight','Off','default'),('ThemeLight','On','default'),
               ('ThemeDark','Off','default'),('ThemeDark','On','default'),
               ('Glass','Off','default'),('Glass','On','default'),('Glass','On','focus')]
        ids=[]
        for i,(kind,on,state) in enumerate(specs):
            x,y=60+(i%4)*308,230+(i//4)*300
            key=f'Kind={kind}, Selected={on}, State={state}'
            label={'Glass':'Liquid Glass','ThemeSystem':'Automatico','ThemeLight':'Chiaro','ThemeDark':'Scuro'}.get(kind,'Italiano')
            hint={'ThemeSystem':'Segue Windows','ThemeLight':'Luce naturale','ThemeDark':'Luce soffusa'}.get(kind,'Trasparenza attiva' if kind=='Glass' and on=='On' else 'Superficie opaca' if kind=='Glass' else 'IT')
            draw_kind={'ThemeSystem':'theme-system','ThemeLight':'theme-light','ThemeDark':'theme-dark','Glass':'toggle'}.get(kind,'language')
            c=self.option(boards[0],key,x,y,kind=draw_kind,selected=on=='On',state=state,label=label,hint=hint)
            ids.append(c)
            self.instance(c,boards[1],x,y)
            for b in boards:
                self.text(b,f'{kind} / {on} / {state}',x,y-30,270,12,'secondary',True)
                self.text(b,'144 × 144 · raggio 22\nTarget nativo 160 × 160',x,y+164,260,12,'secondary',h=44)
        self.combine('OptionTile',ids)
        print(f'OptionTile: {len(ids)} variants',flush=True)

    def controls_page(self):
        p=self.page('04 / Campi e comandi')
        boards=[self.board(p,'Campi e comandi',m,i*1400,h=1390) for i,m in enumerate(TOKENS)]
        for family,states,y in [('Field',['default','focus','error'],230),('Save',['default','hover','pressed','focus'],490),
                                ('Keycap',['Letter','Space','Minus','Plus'],710),('Status',['ready','paused','dirty','saved','error'],930)]:
            ids=[]
            for i,state in enumerate(states):
                cols=3 if family=='Field' else 4
                x,yy=60+(i%cols)*306,y+(i//cols)*150
                w,h=(270,90) if family=='Field' else (216,48) if family=='Save' else ((100,34) if state=='Space' else (34,34) if state=='Letter' else (30,30)) if family=='Keycap' else (260,76)
                key='State='+state
                c=self.component(boards[0],family,key,x,yy,w,h)
                if family=='Field':
                    self.text(c,'App escluse',0,0,w,12,'secondary',h=20)
                    self.rect(c,'Inset field',0,28,w,43,'inset',r=12)
                    edge=self.rect(c,'Field edge',0,28,w,43,r=12,fills=[],stroke=TOKENS['Light']['error' if state=='error' else 'accent' if state=='focus' else 'separator'],strokeWeight=1.6 if state!='default' else 1)
                    self.bind(edge,'stroke','error' if state=='error' else 'accent' if state=='focus' else 'separator')
                    label=self.text(c,'notepad.exe',12,31,w-24,13,h=36)
                    self.property(c,'Value',label,'notepad.exe')
                    if state=='error': self.text(c,'Usa il nome completo: app.exe',2,72,w,10,'error',h=18)
                elif family=='Save':
                    self.glass(c,0,0,w,h,14,True,state)
                    self.rect(c,'Primary action',1,1,w-2,h-2,r=13,fills=[{'type':'gradient','kind':'linear','from':[0,0],'to':[1,1],
                        'stops':[{'position':0,'color':color('#6191FA')},{'position':.5,'color':color('#3D6ED6')},{'position':1,'color':color('#2952B8')}]}])
                    if state=='hover': self.rect(c,'Hover',1,1,w-2,h-2,'hover',r=13)
                    self.text(c,'Salva modifiche',0,0,w,14,bold=True,h=h,align='center')
                    # White labels stay white in both appearance modes.
                    label=self.m.call('get_node',id=c,depth=1)['children'][-1]['id']
                    self.m.command('variable.bind',ids=[label],field='fill',variable=None)
                    self.set(label,fill='#FFFFFF')
                elif family=='Keycap':
                    self.glass(c,0,0,w,h,9)
                    self.text(c,{'Letter':'e','Space':'Spazio','Minus':'−','Plus':'+'}[state],0,0,w,14,bold=True,h=h,align='center')
                else:
                    self.node('ellipse',c,'Status dot',0,23,7,7,'success' if state in ['ready','saved'] else 'error' if state=='error' else 'secondary')
                    self.text(c,{'ready':'Pronto a scrivere','paused':'In pausa','dirty':'Modifiche da salvare','saved':'Impostazioni salvate','error':'Scegli un ritardo fra 100 e 1500 ms.'}[state],16,0,w-16,12,'error' if state=='error' else 'secondary',h=54)
                ids.append(c)
                self.instance(c,boards[1],x,yy)
                for b in boards: self.text(b,f'{family} / {state}',x,yy-29,280,12,'secondary',True)
            self.combine(family,ids)
        print('Fields, save, keycaps, status: 16 variants',flush=True)

    def picker(self,p,x,y,selected=True,opaque=False,upper=False,component=False):
        key=f'Selection={"On" if selected else "Off"}, Material={"Opaque" if opaque else "Glass"}, Case={"Upper" if upper else "Lower"}'
        c=self.component(p,'Picker',key,x,y,272,142) if component else self.node('frame',p,'Picker / '+key,x,y,272,142,fills=[],clip=False)
        self.glass(c,0,0,272,142,25,material='opaque' if opaque else 'glass')
        self.text(c,'Varianti di '+('E' if upper else 'e'),18,7,236,11,'secondary',h=22)
        for j,glyph in enumerate(['È','É'] if upper else ['è','é']):
            source=self.components[('Candidate',f'Selected={"On" if selected and j==0 else "Off"}, Material={"Opaque" if opaque else "Glass"}')]
            self.instance(source,c,66+j*76,34,Glyph=glyph)
        self.text(c,'← → scegli',18,110,136,10.5,'secondary',h=22)
        self.text(c,'Esc annulla',172,110,84,10.5,'secondary',h=22,align='center')
        return c

    def picker_page(self):
        p=self.page('02 / App · selettore')
        boards=[self.board(p,'Il selettore degli accenti',m,i*1400,h=1100) for i,m in enumerate(TOKENS)]
        ids=[]
        for i,(on,mat) in enumerate([(False,'glass'),(True,'glass'),(False,'opaque'),(True,'opaque')]):
            x=60+i*306
            key=f'Selected={"On" if on else "Off"}, Material={mat.title()}'
            c=self.candidate(boards[0],key,x,230,on,mat)
            ids.append(c); self.instance(c,boards[1],x,230)
            for b in boards:
                self.text(b,f'Candidate / {"scelto" if on else "neutro"}\n{mat} · 64 × 64 · R16',x,310,270,12,'secondary',h=44)
        self.combine('Candidate',ids)
        ids=[]
        for i,(selected,opaque,upper) in enumerate([(False,False,False),(True,False,False),(True,True,False),(True,False,True)]):
            x,y=60+(i%2)*610,440+(i//2)*270
            c=self.picker(boards[0],x,y,selected,opaque,upper,True)
            ids.append(c); self.instance(c,boards[1],x,y)
            for b in boards:
                self.text(b,['Apertura / nessuna scelta','Scelta / conferma al rilascio','Trasparenza disattivata','Maiuscole / Shift o Caps Lock'][i],x,y-30,540,14,'secondary',True)
        self.combine('Picker',ids)
        for b in boards:
            self.text(b,'Il focus resta dove stai scrivendo.',60,1000,1100,20,bold=True)
        print('Candidate + Picker: 8 variants',flush=True)

    def find_option(self,kind,selected,state='default'):
        return self.components[('OptionTile',f'Kind={kind}, Selected={"On" if selected else "Off"}, State={state}')]

    def settings(self,p,mode,x,y,name='Impostazioni',compact=False):
        c=self.frame(p,name+' / '+mode,mode,x,y,900 if not compact else 660,936 if not compact else 600)
        if compact:
            inner,_=self.settings(c,mode,0,0,name='Contenuto / fine scorrimento')
            self.m.command('transform.scale',ids=[inner],factor=660/900)
            self.set(inner,x=0,y=600-936*660/900)
            self.set(c,name='Impostazioni compatte / '+mode)
            return c,{}
        self.rect(c,'Ambient header light',0,0,900,116,r=0,fills=[{'type':'gradient','kind':'linear','from':[0,0],'to':[1,1],
            'stops':[{'position':0,'color':color('#D6E6FF' if mode=='Light' else '#29304A')},
                     {'position':.65,'color':color(TOKENS[mode]['canvas'])},{'position':1,'color':color(TOKENS[mode]['canvas'])}]}])
        self.glass(c,32,27,54,54,16)
        self.text(c,'á',32,24,54,30,bold=True,h=54,align='center')
        self.text(c,'Accento',104,22,410,34,bold=True,h=43)
        self.text(c,'Un piccolo gesto. La lettera giusta.',106,66,470,14,'secondary',h=24)
        self.rect(c,'Ready badge',714,40,150,32,'inset',r=16)
        self.node('ellipse',c,'Ready dot',728,53,7,7,'success')
        self.text(c,'Pronto a scrivere',744,44,112,11,'secondary',True,h=24)
        self.rect(c,'Header divider',32,109,836,1,'separator')
        self.glass(c,32,132,410,112,24)
        self.glass(c,458,132,410,112,24)
        self.text(c,'Il tuo ritmo',52,144,360,18,bold=True)
        self.text(c,'Ritardo di apertura',52,180,160,13,'secondary')
        for xx,sign in [(210,'−'),(340,'+')]:
            self.glass(c,xx,176,28,28,9)
            self.text(c,sign,xx,176,28,17,h=28,align='center')
        self.rect(c,'Delay inset',246,170,82,40,'inset',r=12)
        self.text(c,'300',251,180,72,14,h=22)
        self.text(c,'ms',380,180,40,11,'secondary')
        self.text(c,'Da 100 a 1500 ms',52,210,350,10,'secondary')
        self.text(c,'Un gesto naturale',478,144,360,18,bold=True)
        for xx,ww,label in [(480,34,'e'),(550,100,'Spazio')]:
            self.glass(c,xx,182,ww,34,9)
            self.text(c,label,xx,182,ww,14,bold=True,h=34,align='center')
        self.text(c,'+',526,186,24,14,'tertiary')
        self.text(c,'Scegli, poi rilascia.',674,186,164,12,'secondary')
        self.text(c,'Le tue lingue',36,266,700,20,bold=True)
        self.text(c,'Aspetto',36,480,700,20,bold=True)
        controls={}
        for i,(glyph,label,hint) in enumerate([('à','Italiano','IT'),('ç','Français','FR'),('ñ','Español','ES'),('ü','Deutsch','DE')]):
            controls[hint]=self.instance(self.find_option('Language',i==0),c,36+i*166,308,Glyph=glyph,Label=label,Hint=hint)
        for i,label in enumerate(['Automatico','Chiaro','Scuro','Liquid Glass']):
            kind=['ThemeSystem','ThemeLight','ThemeDark','Glass'][i]
            controls[label]=self.instance(self.find_option(kind,i==3 or (i==1 if mode=='Light' else i==2)),c,36+i*166,522,
                Label=label,Hint=['Segue Windows','Luce naturale','Luce soffusa','Trasparenza attiva'][i])
        for yy,title,lines in [(336,"Sempre nell'ordine giusto",'Le varianti si combinano.\nNessun duplicato.'),(550,'A modo tuo','Luce, profondità, contrasto.\nAnche senza trasparenza.')]:
            self.text(c,title,714,yy,170,12,'secondary',True)
            self.text(c,lines,714,yy+30,170,11,'tertiary',h=48)
        for xx,title,helper in [(32,'App escluse','Nomi completi, separati da virgola.'),(458,'Prova il tuo prossimo accento','Tieni e · Spazio · scegli con le frecce · rilascia')]:
            self.glass(c,xx,704,410,128,24)
            self.text(c,title,xx+22,716,366,17,bold=True,h=27)
            self.text(c,helper,xx+22,744,366,11,'secondary',h=21)
            self.rect(c,'Editable field inset',xx+16,764,378,43,'inset',r=12)
        self.rect(c,'Footer divider',32,854,836,1,'separator')
        self.text(c,'Modifiche da salvare',36,870,560,13,'secondary',True,h=23)
        self.text(c,'Solo sul tuo dispositivo. Nessun account.',36,895,560,11,'tertiary',h=20)
        controls['Save']=self.instance(self.components[('Save','State=default')],c,652,870)
        return c,controls

    def foundations(self):
        p=self.page('01 / Fondamenti')
        for i,mode in enumerate(TOKENS):
            b=self.board(p,'Luce, materia, proporzione',mode,i*1400,h=1420)
            for j,role in enumerate(TOKENS[mode]):
                x,y=52+(j%6)*206,218+(j//6)*116
                self.rect(b,role,x,y,178,48,role,r=12)
                self.text(b,role,x,y+54,186,11,bold=True)
                self.text(b,TOKENS[mode][role],x,y+73,186,10,'secondary')
            self.text(b,'Una superficie, cinque dettagli.',52,614,1200,25,bold=True)
            self.glass(b,56,672,180,180,28,True)
            self.text(b,'á',56,688,180,68,h=120,align='center')
            for j,line in enumerate(['01 / luce diagonale a tre stop','02 / tinta solo sulla selezione',
                                     '03 / bordo esterno luminoso, 1 px','04 / bordo interno, 0,6 px',
                                     '05 / ombra corta, quota costante']):
                self.text(b,line,284,678+j*34,880,15,'secondary')
            self.text(b,'Segoe UI Variable',52,904,1100,34,bold=True)
            self.text(b,'Titolo 34 · sezione 20 · pannello 17 · controllo 14',52,958,1160,17)
            self.text(b,'Testo 13 · supporto 12 / 11 · dettaglio 10 · accento 32 / 40',52,994,1160,13,'secondary')
            for j,(size,radius,label) in enumerate([(64,16,'Candidato'),(144,22,'Opzione'),(43,12,'Campo')]):
                xx=52+j*410
                self.text(b,f'{label} / {size} · R{radius}',xx,1070,370,16,bold=True)
                self.text(b,'Spazi 4 · 8 · 12 · 16 · 24 · 32\nFocus esterno 2 px / distanza 2,5 px',xx,1112,370,13,'secondary',h=64)
            self.text(b,'Il materiale del selettore usa Acrylic su Windows. I pannelli delle impostazioni usano luce e bordi disegnati.',52,1240,1200,13,'secondary',h=48)
            self.text(b,'Le variabili del file sono collegate ai layer, comprese le fermate dei gradienti. Valori scalari in accento.tokens.json.',52,1300,1200,12,'secondary',h=40)

    def screens(self):
        p=self.page('05 / Impostazioni · schermate')
        self.screenboards=[]
        full={}
        for i,mode in enumerate(TOKENS):
            c,controls=self.settings(p,mode,i*1000,0)
            full[mode]=(c,controls)
            self.screenboards.append({'id':c,'name':'settings','mode':mode,'width':900,'height':936})
        for mode in TOKENS:
            for label in ['Chiaro','Scuro']:
                self.m.command('proto.interaction.add',id=full[mode][1][label],
                               action={'type':'navigate','dest':full['Light' if label=='Chiaro' else 'Dark'][0]},
                               transition={'type':'instant'})
        self.m.command('proto.flow.add',start=full['Light'][0],name='Impostazioni / cambia tema')
        c,_=self.settings(p,'Dark',2000,0,compact=True)
        self.screenboards.append({'id':c,'name':'settings-compact','mode':'Dark','width':660,'height':600})
        self.boards.extend(self.screenboards)
        print('Full editable settings screens + compact viewport',flush=True)

    def overview(self):
        p=self.pages[0]
        self.m.command('page.select',id=p)
        b=self.board(p,'Un piccolo gesto. La lettera giusta.','Dark',w=1480,h=1140)
        self.text(b,'Un accento, uno spazio, una scelta.',56,202,970,40,bold=True,h=60)
        self.text(b,'Ogni opzione ha il suo spazio. La luce rende leggibile la profondità.',58,278,1260,18,'secondary')
        self.picker(b,64,364)
        self.picker(b,432,364,opaque=True)
        self.text(b,'Selettore / Glass',64,530,310,14,'secondary')
        self.text(b,'Selettore / opaco',432,530,310,14,'secondary')
        for i,(glyph,label,hint) in enumerate([('à','Italiano','IT'),('ç','Français','FR'),('ñ','Español','ES'),('ü','Deutsch','DE')]):
            self.instance(self.find_option('Language',i==0),b,64+i*180,636,Glyph=glyph,Label=label,Hint=hint)
        self.text(b,'144 × 144',64,810,720,26,bold=True)
        self.text(b,'Tessere quadrate. Bordi ottici. Selezione azzurra. Focus visibile.',64,858,740,15,'secondary',h=48)
        self.glass(b,872,364,544,588,28)
        self.text(b,'Dentro il sistema',904,396,470,26,bold=True)
        for i,(a,txt) in enumerate([('01','Fondamenti / colori e materiali'),('02','App / candidati e selettore'),
                                   ('03','Opzioni / lingue, temi e Glass'),('04','Controlli / campi, comandi e stato'),
                                   ('05','Impostazioni / Light, Dark e compatta'),('06','Interazione / regole e collegamenti Rust')]):
            self.text(b,a,904,458+i*66,38,12,'accent',True)
            self.text(b,txt,950,454+i*66,440,14,'secondary',h=44)
        self.text(b,'COMPONENTI COLLEGATI  /  VARIABILI LIGHT + DARK  /  FILE NATIVO MODIFICABILE',64,1020,1350,12,'secondary',True)

    def handoff(self):
        p=self.page('06 / Interazioni e sviluppo')
        b=self.board(p,'Dalla tavola al gesto','Light',h=1210)
        lines=[('Attivazione','Tieni la lettera, premi e rilascia Spazio. Apertura dopo 300 ms. Nessuna scelta iniziale.'),
               ('Navigazione','Sinistra / Destra o una nuova pressione di Spazio. La selezione usa bordo, tinta, colore e punto.'),
               ('Conferma','Rilascia la lettera. Il selettore conserva il focus nel campo di destinazione.'),
               ('Annullamento','Esc, cambio campo o finestra, click o rotella. La base resta disponibile.'),
               ('Lingue','Selezione multipla; almeno una lingua. L’ordine dei candidati è stabile e senza duplicati.'),
               ('Aspetto','Una modalità alla volta. Anteprima nelle impostazioni; il pulsante Salva applica e conserva.'),
               ('Feedback','Hover luminoso, pressione di 1 px, focus esterno. Il colore non è l’unico segnale di scelta.'),
               ('Validazione','Ritardo 100–1500 ms. Messaggio vicino alle opzioni, bordo del campo e dati conservati.'),
               ('Finestra ridotta','Scala uniforme alla larghezza; scorrimento verticale. Tab porta il controllo in vista.')]
        for i,(title,body) in enumerate(lines):
            y=208+i*82
            self.text(b,f'{i+1:02d}',52,y,46,12,'accent',True)
            self.text(b,title,108,y,300,17,bold=True)
            self.text(b,body,412,y,840,13,'secondary',h=58)
            self.rect(b,'Rule',52,y+68,1216,1,'separator')
        self.text(b,'Sorgenti',52,980,290,23,bold=True)
        self.text(b,'glass.rs → materiale e palette   /   render.rs → selettore   /   app/settings.rs → impostazioni',52,1026,1216,13,'secondary')
        self.text(b,'Prototipo: Chiaro e Scuro navigano fra le schermate. Le tavole statiche non simulano hook, scrittura o salvataggio.',52,1074,1216,12,'secondary',h=44)

    def tray(self):
        p=self.page('07 / Area di notifica')
        boards=[self.board(p,'Sempre a portata di scrittura',m,i*1400,h=900) for i,m in enumerate(TOKENS)]
        icon=self.component(boards[0],'TrayIcon','Size=32',60,234,32,32)
        self.rect(icon,'Accento mark / blue',0,0,32,32,r=7,fill='#2A64E0')
        self.node('vector',icon,'A and accent / original geometry',8,5,16,20,
                  path='M 1 19 L 8 4 L 15 19 M 4 13 L 12 13 M 10 1 L 14 0',
                  fills=[],stroke='#FFFFFF',strokeWeight=2,strokeCap='round',strokeJoin='round')
        self.instance(icon,boards[1],60,234)
        ids=[]
        for i,paused in enumerate([False,True]):
            x,y=60+i*610,380
            c=self.component(boards[0],'TrayMenu','Paused='+('On' if paused else 'Off'),x,y,260,174)
            self.rect(c,'System menu reference',0,0,260,174,'inset',r=8,stroke='#8999B947',strokeWeight=1,
                      effects=[{'type':'dropShadow','color':'#00000024','radius':12,'offsetX':0,'offsetY':6}])
            for j,label in enumerate(['Impostazioni','Riprendi' if paused else 'Pausa','Esci']):
                self.text(c,label,20,12+j*50,220,14,h=38)
            self.rect(c,'Separator',12,110,236,1,'separator')
            ids.append(c); self.instance(c,boards[1],x,y)
            for b in boards: self.text(b,'In pausa' if paused else 'Attivo',x,y-40,550,20,bold=True)
        self.combine('TrayMenu',ids)
        for b in boards:
            self.text(b,'Chiudere le impostazioni lascia attiva l’utility.',60,640,1180,24,bold=True)
            self.text(b,'Icona nell’area di notifica · doppio click per le impostazioni · menu per pausa, ripresa e uscita.',60,698,1180,15,'secondary',h=48)
            self.text(b,'Il menu è un riferimento dei comandi: il rendering effettivo resta quello del menu contestuale Windows.',60,786,1180,12,'secondary',h=40)

    def finish(self):
        self.m.command('page.select',id=self.pages[0])
        self.m.call('select',ids=[])
        path=OUT/'Accento-Design-System.figcraft'
        self.m.call('save_file',path=str(path))
        self.m.call('open_file',path=str(path))
        doc=self.m.call('inspect_document',depth=14,allPages=True)
        inventory=self.m.command('component.list')
        mains=[c for c in inventory if c['type']=='COMPONENT']
        sets=[c for c in inventory if c['type']=='COMPONENT_SET']
        assert len(doc['pages'])==8
        assert len(mains)==len(self.components)
        assert {s['name'] for s in sets}==set(self.sets)
        self.m.command('variable.export',path=str(OUT/'accento.variables.json'))
        variables=json.loads((OUT/'accento.variables.json').read_text(encoding='utf-8'))
        assert len(variables['meta']['variables'])==len(self.variables)
        assert len(doc['styles'])==len(self.styles)
        (OUT/'accento.inspection.json').write_text(json.dumps(doc,ensure_ascii=False,indent=2),encoding='utf-8')
        for i,b in enumerate(self.boards):
            filename=f'{i:02d}-{b["name"].lower().replace(" / ","-").replace(" ","-")}-{b["mode"].lower()}.png'
            b['preview']=filename
            self.m.call('export',ids=[b['id']],format='png',scale=1,path=str(OUT/'previews'/filename))
        manifest={'file':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
                  'pages':len(doc['pages']),'mainComponents':len(mains),'componentSets':len(sets),
                  'variables':len(self.variables),'textStyles':len(self.styles),'boards':self.boards,
                  'components':inventory,'verification':'Native file saved, reopened, inspected; all artboards exported.',
                  'limitations':['Prototype links only switch settings Light/Dark screens.',
                                 'Optical glass is a Windows adaptation; design canvas does not prove native backdrop or accessibility.']}
        (OUT/'accento.manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
        (OUT/'accento.tokens.json').write_text(json.dumps({'contract':'accento.glass/1','modes':TOKENS,'metrics':METRICS,
            'unit':'Windows DIP at 96 DPI','font':'Segoe UI Variable','runtimeSources':['crates/accento-windows/src/glass.rs',
            'crates/accento-windows/src/render.rs','crates/accento-windows/src/app/settings.rs']},ensure_ascii=False,indent=2),encoding='utf-8')
        mapping={'version':1,'unit':'DIP','components':{
            'Candidate':'crates/accento-windows/src/render.rs / Renderer::picker',
            'Picker':'crates/accento-windows/src/render.rs / Renderer::picker',
            'OptionTile':'crates/accento-windows/src/app/settings.rs / draw_item',
            'Field':'crates/accento-windows/src/app/settings.rs / canvas + native Edit',
            'Save':'crates/accento-windows/src/app/settings.rs / draw_item',
            'Keycap':'crates/accento-windows/src/app/settings.rs / keycap',
            'Status':'crates/accento-windows/src/app/settings.rs / canvas',
            'TrayIcon':'crates/accento-windows/build.rs + src/app.rs / create_icon',
            'TrayMenu':'crates/accento-windows/src/app.rs / settings_proc'},
            'sharedMaterial':'crates/accento-windows/src/glass.rs / Palette + Painter::card',
            'prototype':'Click Chiaro / Scuro on full settings screens to navigate between appearances.',
            'scope':'Editable optical references. Native window chrome, input hooks, persistence, backdrop and accessibility require runtime verification.'}
        (OUT/'handoff.json').write_text(json.dumps(mapping,ensure_ascii=False,indent=2),encoding='utf-8')
        print(json.dumps({k:v for k,v in manifest.items() if k not in ['components','boards','limitations']},ensure_ascii=False),flush=True)


def build():
    s=System()
    try:
        s.page('00 / Accento')
        s.foundations()
        s.picker_page()
        s.options_page()
        s.controls_page()
        s.screens()
        s.overview()
        s.handoff()
        s.tray()
        s.finish()
    finally:
        s.m.close()


if __name__=='__main__':
    build()
