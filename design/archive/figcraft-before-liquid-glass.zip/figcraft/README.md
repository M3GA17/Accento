# Accento / Design system FigCraft

Apri **Accento-Design-System.figcraft** in FigCraft. Il file è nativo e modificabile: testi, vettori, gradienti, componenti, istanze, variabili e stili restano separati. Non contiene screenshot incorporati.

Creato con FigCraft 0.6.0, il 15 ottobre 2026. Il progetto accompagna il rework Rust 0.2.0.

| Pagina | Contenuti |
| --- | --- |
| 00 / Accento | Panoramica del linguaggio visivo |
| 01 / Fondamenti | Palette Light/Dark, materiale a strati, tipografia, geometria |
| 02 / App · selettore | Candidati, scelta, maiuscole, versione opaca |
| 03 / Opzioni quadrate | Lingue, Automatico/Chiaro/Scuro, Glass, hover, pressione e focus |
| 04 / Campi e comandi | Campi neutri/focus/errore, salvataggio, keycap, feedback |
| 05 / Impostazioni · schermate | Schermate complete Light/Dark e viewport compatta |
| 06 / Interazioni e sviluppo | Gesto, conferma, annullamento, preferenze e mappa Rust |
| 07 / Area di notifica | Icona, comandi attivo/in pausa |

Sono presenti **42 componenti principali**, **8 set**, **43 variabili** con modalità Light/Dark e **27 stili tipografici**. Le dimensioni sono DIP Windows a 96 DPI. I colori dei layer e gli stop dei gradienti sono collegati alle variabili; candidati e opzioni espongono proprietà testuali modificabili nelle istanze.

Il flusso di prototipo **Impostazioni / cambia tema** collega Chiaro e Scuro alle due schermate. Gli altri stati sono riferimenti visivi modificabili: il file non simula inserimento, hook, validazione o salvataggio del software.

## File

- `Accento-Design-System.figcraft`: progetto autorevole.
- `previews/`: 15 tavole esportate dal file riaperto.
- `accento.tokens.json`: colori e misure leggibili fuori dall'editor.
- `accento.variables.json`: esportazione delle variabili native.
- `handoff.json`: corrispondenza fra componenti e sorgenti Rust.
- `accento.manifest.json`: inventario, tavole e hash del progetto.
- `accento.inspection.json`: struttura dei layer dopo la riapertura.

Per rigenerare da Accento: `python scripts/create-figcraft-system.py`. Richiede FigCraft installato; il percorso della CLI è configurabile con `FIGCRAFT_CLI`. Il generatore usa il server MCP stdio della CLI, senza modificare configurazioni permanenti o pubblicare librerie. La rigenerazione sostituisce i file generati: le modifiche manuali vanno salvate prima in una copia.

## Verifica e limiti

Il generatore salva e riapre il `.figcraft`, controlla conteggi di pagine, componenti, set, variabili e stili, quindi esporta tutte le 15 tavole. Sono state osservate le impostazioni chiare/scure, i controlli chiari, i candidati chiari, le opzioni chiare, i fondamenti chiari, la panoramica scura, la viewport compatta e l'area di notifica scura. La revisione ha corretto centratura dei testi, anteprime dei temi, doppia moltiplicazione dell'alpha nei colori collegati e misure dei keycap.

Le tavole descrivono il materiale ottico di Accento; la variante opaca del canvas è un riferimento semplificato. Il backdrop e il menu contestuale effettivi restano gestiti da Windows. Il file non certifica accessibilità, rifrazione Apple o interoperabilità Figma. Le verifiche del software sono nel rapporto `docs/verifiche-0.2.0.md`.
