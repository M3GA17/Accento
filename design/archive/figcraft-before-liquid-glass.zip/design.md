# Direzione visiva di Accento

Accento adotta una presentazione Glass ispirata ad Apple. La priorità è rendere immediatamente riconoscibile la variante scelta mentre l'attenzione resta sulla scrittura.

## Riferimento e adattamento

La [ricerca Apple DimaLabs](../../DimaLabs.DesignSystem/docs/ricerca-apple-design-moderno.md) distingue Liquid Glass, materiali visionOS e adattamenti web. La [traduzione pratica](../../DimaLabs.DesignSystem/docs/apple-glass-pratica-web.md) aiuta a separare materiali, contenuto e controlli.

Per Accento si propone una barra funzionale compatta. La finestra Music visionOS studiata nel laboratorio non viene ripresa come struttura dell'utility: sidebar e grandi aree di contenuto rispondono a un altro compito.

Il materiale Windows sarà una realizzazione propria. Traslucenza e sfocatura non garantiscono rifrazione, vibrancy o adattamento del materiale Apple. L'effetto di sfondo deve essere provato sulla finestra reale: il solo blur CSS non dimostra la visibilità del desktop sottostante.

Il [piano del selettore Glass](piano-ricreazione-rust.md#esperimento-del-selettore-glass) propone una prima prova Win32 controllata da Rust e un confronto con il backdrop DWM per finestre transitorie. La sua disponibilità dalla build Windows 11 22621 delimita l'esperimento; non fissa ancora il sistema minimo del prodotto. La variante opaca usa gli stessi contenuti e la stessa gerarchia.

## Selettore dei caratteri

La revisione 0.2.0 segue la richiesta esplicita di box quadrate indipendenti. Ogni candidato ha una tessera 64 × 64 DIP, raggio 16 e distanza 12. La superficie flottante contiene intestazione, candidati e aiuti da tastiera; l'altezza è 142 DIP. La variante selezionata combina tinta azzurra, bordo, colore del carattere e punto inferiore.

Esempio di contenuto per una sessione sulla lettera e: `è  é  ê  ë`. È uno schema di contenuto, non una mappatura linguistica completa né un'anteprima del rendering.

Il testo è l'elemento dominante. Nome Unicode e codice possono diventare dettagli facoltativi; non devono occupare stabilmente lo spazio necessario alla scelta rapida.

I gruppi troppo lunghi richiedono navigazione e indicazione della presenza di altri candidati. Il layout deve essere verificato con set combinati prima di scegliere tra scorrimento e paginazione.

## Finestra impostazioni

La prima proposta comprende cinque gruppi, nella stessa finestra se lo spazio lo consente:

- Attivazione, con gesto e ritardo.
- Lingue, con anteprima dei caratteri disponibili.
- Aspetto, con modalità chiara, scura, di sistema e riduzione della trasparenza.
- Applicazioni, con elenco delle esclusioni e spiegazione del confronto.
- Generale, con stato dell'app e avvio automatico facoltativo.

Nella revisione implementata, le opzioni lingua, tema e materiale hanno tessere 144 × 144 DIP, raggio 22, dentro target nativi 160 × 160. Lingue e aspetto occupano due righe; pannelli separati contengono ritardo, gesto, esclusioni e campo di prova. Il canvas è 900 × 936 DIP, con scala alla larghezza e scorrimento verticale nelle finestre ridotte.

Il tema cambia in anteprima. **Salva modifiche** applica e conserva le preferenze; il footer distingue dati pendenti, successo ed errore. I campi conservano l'input non valido, mostrano il bordo di errore e un messaggio di correzione. Hover, pressione e focus hanno stati distinti. Il focus usa un anello esterno di 2 DIP.

Il [file FigCraft nativo](../design/figcraft/Accento-Design-System.figcraft) contiene fondamenti, componenti, schermate Light/Dark, vista compatta, selettore e area di notifica. Le schermate riusano istanze dei componenti. [Inventario e verifiche](../design/figcraft/README.md).

## Materiali e movimento

Il materiale deve funzionare sopra documenti bianchi, editor scuri, fotografie e sfondi molto contrastati. Il testo ha un supporto sufficientemente solido anche quando lo sfondo varia. Un'opzione opaca conserva la stessa gerarchia.

Il renderer condiviso usa luce diagonale a tre stop, bordo esterno luminoso da 1 DIP, bordo interno da 0,6 DIP e ombre corte. Le impostazioni mantengono un target opaco compatibile con i campi Edit nativi; il selettore usa il backdrop Windows quando disponibile. Questo materiale è un adattamento visivo proprio: il canvas FigCraft non dimostra rifrazione o composizione Apple.

Apertura, spostamento della selezione e chiusura possono avere transizioni brevi. Il gesto di conferma non deve attendere l'animazione. Non sono previste animazioni ambientali continue o riflessi decorativi periodici.

## Accessibilità e tipografia

Usare inizialmente font di sistema Windows con copertura delle lingue supportate. Font e simboli Apple non sono dipendenze del prodotto. La disponibilità di una risorsa di design non costituisce automaticamente un diritto di redistribuzione.

Impostazioni e selettore richiedono prove separate: il primo è una finestra interattiva, il secondo conserva il focus nel destinatario. Vanno progettati esposizione accessibile dei candidati e annunci della selezione senza rubare il focus o sovraccaricare il lettore di schermo.

Le verifiche comprendono tastiera, Narrator, scala del testo, monitor con DPI diversi, contrasto elevato, riduzione del movimento e trasparenza disattivata. Un risultato positivo nel catalogo React non dimostra il comportamento del selettore Windows.

## Ruoli visivi

Definire ruoli per superficie, testo primario, testo secondario, selezione, bordo, focus, spaziatura e movimento. Colori e dimensioni saranno scelti su un prototipo reale. Se viene adottato un formato DTCG, il vocabolario di Accento sarà esplicito; non si presume compatibilità con i temi Material o Glass esistenti.

